function vec = nucleacid2masses(na)

global naMass

vec = [];
for c=1:length(na)
    vec = [vec,naMass(naToInd(na(c)))];
end
