function ind = naToInd(na)

str = 'ATCGXaucgxP';
ind = strfind(str,na);
if (isempty(ind))
    error(['Unknown nucleic acid letter: ',na])
end