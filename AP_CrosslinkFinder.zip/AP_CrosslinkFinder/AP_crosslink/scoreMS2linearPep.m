function [bScore,yScore,ppms] = scoreMS2linearPep(trueMassList,seq,postCalb,toPrint) 

global ms2PreCalbFit ms2PostCalbFit ms2offset

if (postCalb)
    tol = ms2PostCalbFit;
else
    tol = ms2PreCalbFit;
end

monoIsotopicMasses = trueMassList(:,1);
assigned = zeros(length(monoIsotopicMasses),1);
bScore = 0;
yScore = 0;
ppms = [];
pepMasses = peptide2masses(seq);

bSeries = getBseries(pepMasses);
for c=1:length(bSeries)
    desiredMass = bSeries(c);
    if (desiredMass>0) % not doing N-terminal Zs
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6 - ms2offset)<tol);
    else
        foundInd = [];
    end
    assigned(foundInd) = 1;
    if (~isempty(foundInd))
        bScore = bScore + 1;
        ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6 - ms2offset, desiredMass]];
        if (toPrint)
            fprintf(1,'b');
        end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
if (toPrint)
    fprintf(1,' \n%s\n ',seq);
end
ySeries = getYseries(pepMasses);
for c=1:length(ySeries)
    desiredMass = ySeries(c);
    if (desiredMass>0) % not doing N-terminal Zs
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6 - ms2offset)<tol);
    else
        foundInd = [];
    end
    assigned(foundInd) = 1;
    if (~isempty(foundInd))
        yScore = yScore + 1;
        ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6 - ms2offset, desiredMass]];
        if (toPrint)
            fprintf(1,'y');
        end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
if (toPrint)
    fprintf(1,'\n\n');
end

if (toPrint)
    close all
    plot(trueMassList(:,1)./abs(trueMassList(:,3)),trueMassList(:,4),'k.',...
        trueMassList(find(assigned),1)./abs(trueMassList(find(assigned),3)),trueMassList(find(assigned),4),'r.')
end
