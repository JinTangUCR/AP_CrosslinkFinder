function ySeries = getYseries(pep)

global waterMass

ySeries = [];
for c=2:length(pep)
    ySeries = [ySeries , sum(pep(c:end)) + waterMass];
end
