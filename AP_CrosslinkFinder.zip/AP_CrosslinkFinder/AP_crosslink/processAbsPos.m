function val = processAbsPos(seqID,pos)

val = pos - 1; % eliminating the fitst N-term Z.


