function report = mergeIonReports(analysisFiles)

reportCounter = 0;
report=[];

for c=1:length(analysisFiles(:,1)) %number of output .mat files
    fprintf('reading file: %s\n', deblank(analysisFiles(c,:)))
    load(deblank(analysisFiles(c,:)));
    oneReport = makeReportByIons(ms1);
    for cc=1:length(oneReport)
        relScore = oneReport(cc).relScore;
        intens = oneReport(cc).intens;
        duplicateInd = findEnteryInReport(report,oneReport(cc).seqP,oneReport(cc).seqD);
        if (isempty(duplicateInd))
            reportCounter = reportCounter + 1;
            report(reportCounter).seqP = oneReport(cc).seqP;
            report(reportCounter).seqD = oneReport(cc).seqD;
            report(reportCounter).resP = oneReport(cc).resP;
            report(reportCounter).resD = oneReport(cc).resD;
            report(reportCounter).ID_P = oneReport(cc).ID_P;
            report(reportCounter).ID_D = oneReport(cc).ID_D;
            report(reportCounter).linkP = oneReport(cc).linkP;
            report(reportCounter).linkD = oneReport(cc).linkD;
            report(reportCounter).score = oneReport(cc).score;
            report(reportCounter).relScore = oneReport(cc).relScore;
            report(reportCounter).intens = oneReport(cc).intens;
            report(reportCounter).ch = oneReport(cc).ch;
            report(reportCounter).ppm = oneReport(cc).ppm;
            report(reportCounter).trueMass = oneReport(cc).trueMass;
            report(reportCounter).ms1ind = oneReport(cc).ms1ind;
            report(reportCounter).ms1subInd = oneReport(cc).ms1subInd;
            report(reportCounter).runName = deblank(analysisFiles(c,:));
            report(reportCounter).masses = massList(ms1(oneReport(cc).ms1ind).startTrueMassInd : ms1(oneReport(cc).ms1ind).endTrueMassInd , :);
        else
            if ((relScore>report(duplicateInd).relScore) | ...
                    ((relScore==report(duplicateInd).relScore) & (intens>=report(duplicateInd).intens)))
                report(duplicateInd).seqP = oneReport(cc).seqP;
                report(duplicateInd).seqD = oneReport(cc).seqD;
                report(duplicateInd).resP = oneReport(cc).resP;
                report(duplicateInd).resD = oneReport(cc).resD;
                report(duplicateInd).ID_P = oneReport(cc).ID_P;
                report(duplicateInd).ID_D = oneReport(cc).ID_D;
                report(duplicateInd).linkP = oneReport(cc).linkP;
                report(duplicateInd).linkD = oneReport(cc).linkD;
                report(duplicateInd).score = oneReport(cc).score;
                report(duplicateInd).relScore = oneReport(cc).relScore;
                report(duplicateInd).ch = oneReport(cc).ch;
                report(duplicateInd).ppm = oneReport(cc).ppm;
                report(duplicateInd).trueMass = oneReport(cc).trueMass;
                report(duplicateInd).intens = oneReport(cc).intens;
                report(duplicateInd).ms1ind = oneReport(cc).ms1ind;
                report(duplicateInd).ms1subInd = oneReport(cc).ms1subInd;
                report(duplicateInd).runName = deblank(analysisFiles(c,:));
                report(duplicateInd).masses = massList(ms1(oneReport(cc).ms1ind).startTrueMassInd : ms1(oneReport(cc).ms1ind).endTrueMassInd , :);
            end
        end
    end
    clear ms1 allSpectra
end
