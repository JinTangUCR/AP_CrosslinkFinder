function vec = peptide2masses(pep)

global aaMass

vec = [];
for c=1:length(pep)
    vec = [vec,aaMass(aaToInd(pep(c)))];
end


