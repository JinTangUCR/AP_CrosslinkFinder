clear all

% Change the following file names to the MGF files you want to analyze:
mgfFiles = strvcat('../DPC_data/D2_DPC_6500-7000.mgf');

% Change the following file name to the FASTA file that hold protein sequences:
fastaFileName = '../DPC_data/tfam_sequences.fasta';

% Change the following file name to the txt file that hold DNA sequences:
dnaFileName = '../DPC_data/dna_sequence.txt';

% Change the following to the name of the output file:
reportFileName = '../DPC_data/D2_Crosslink_6500-7000.txt';

masses
analysisFiles = [];
offsets = zeros(length(mgfFiles(:,1)),2); %can input multiple mgf files and analyze them sequentially
for analysisCounter = 1:length(offsets(:,1))
    analysisFiles = strvcat(analysisFiles,strrep(deblank(mgfFiles(analysisCounter,:)),'.mgf','.mat'));
    MGFname = deblank(mgfFiles(analysisCounter,:)); %extract the MGF file name
    fprintf(1,'%.0f. Doing: %s\n',analysisCounter,MGFname)
    ms1offset = offsets(analysisCounter,1);
    ms2offset = offsets(analysisCounter,2);
    MainAnalysis
    save(deblank(analysisFiles(analysisCounter,:)),'ms1','allSpectra','massList') % Save 'ms1','allSpectra', and 'massList' into the .mat file
    clear ms1 allSpectra massList
end
ms1offset = 0;
ms2offset = 0;
makeReport    

