function report = makeReportByIon(ms1)
global ms2RelScoreTH; %0.25

report = [];
reportCounter = 0;
for c=1:length(ms1) %scan through ion list in data
    xlFlag = 0;
    ambigFlag = 0;

    % What is this ion???
    % Best in Type1
    bestSC1 = -1;
    bestInd1 = -1;
    for cc=1:length(ms1(c).fit_type1)
        if (ms1(c).fit_type1(cc).score>bestSC1)
            bestSC1 = ms1(c).fit_type1(cc).score;
            bestInd1 = cc;
        end
    end

    % Best in Type3
    bestSC3 = -1;
    bestInd3 = -1;
    for cc=1:length(ms1(c).fit_type3)
        if (ms1(c).fit_type3(cc).score>bestSC3)
            bestSC3 = ms1(c).fit_type3(cc).score;
            bestInd3 = cc;
        end
    end
    if bestSC3>bestSC1
        % OK, it's a crosslink, but is it unambigious?
        xlFlag = 1;
        %length of peptide+ length of DNA
        normBestSC3 = bestSC3/(length(ms1(c).fit_type3(bestInd3).seqP)+(length(ms1(c).fit_type3(bestInd3).seqD)+1)/2);
        bestInds = [];
        for cc=1:length(ms1(c).fit_type3)
            if (ms1(c).fit_type3(cc).score==bestSC3)
                if (isempty(bestInds))
                    bestInds = cc;
                else
                    if (((abs(length(ms1(c).fit_type3(cc).seqP)-length(ms1(c).fit_type3(bestInds(1)).seqP))<2) & ...
                        (abs(length(ms1(c).fit_type3(cc).seqD)-length(ms1(c).fit_type3(bestInds(1)).seqD))<2) & ...
                        (abs(ms1(c).fit_type3(cc).startResP-ms1(c).fit_type3(bestInds(1)).startResP)<3) & ...
                        (abs(ms1(c).fit_type3(cc).startResD-ms1(c).fit_type3(bestInds(1)).startResD)<3) & ...
                        (ms1(c).fit_type3(cc).ID_P==ms1(c).fit_type3(bestInds(1)).ID_P) & ...
                        (ms1(c).fit_type3(cc).ID_D==ms1(c).fit_type3(bestInds(1)).ID_D))      | ... 
                        ((abs(length(ms1(c).fit_type3(cc).seqP)-length(ms1(c).fit_type3(bestInds(1)).seqD))<2) & ...
                        (abs(length(ms1(c).fit_type3(cc).seqD)-length(ms1(c).fit_type3(bestInds(1)).seqP))<2) & ...
                        (abs(ms1(c).fit_type3(cc).startResP-ms1(c).fit_type3(bestInds(1)).startResD)<3) & ...
                        (abs(ms1(c).fit_type3(cc).startResD-ms1(c).fit_type3(bestInds(1)).startResP)<3) & ...
                        (ms1(c).fit_type3(cc).ID_P==ms1(c).fit_type3(bestInds(1)).ID_P) & ...
                        (ms1(c).fit_type3(cc).ID_D==ms1(c).fit_type3(bestInds(1)).ID_D)))
                        % do nothing - a case of multiple lysine places - or - a case of changing place of modification JUO
                    else
                        bestInds = [bestInds ; cc];
                    end
                end
            end
        end
        if (length(bestInds)>1)
            if (normBestSC3>ms2RelScoreTH) % ambiguity worth reporting
                fprintf(1,'Ambiguity: (%.0f)\n%.0f-%.0f-%s %.0f-%.0f-%s\n%.0f-%.0f-%s %.0f-%.0f-%s\n',bestSC3,...
                    ms1(c).fit_type3(bestInds(1)).ID_P,ms1(c).fit_type3(bestInds(1)).startResP,ms1(c).fit_type3(bestInds(1)).seqP,...
                    ms1(c).fit_type3(bestInds(1)).ID_D,ms1(c).fit_type3(bestInds(1)).startResD,ms1(c).fit_type3(bestInds(1)).seqD,...
                    ms1(c).fit_type3(bestInds(2)).ID_P,ms1(c).fit_type3(bestInds(2)).startResP,ms1(c).fit_type3(bestInds(2)).seqP,...
                    ms1(c).fit_type3(bestInds(2)).ID_D,ms1(c).fit_type3(bestInds(2)).startResD,ms1(c).fit_type3(bestInds(2)).seqD);
            end
            ambigFlag =1;
        end
    end

    if (xlFlag & ~ambigFlag)
        seqP = ms1(c).fit_type3(bestInds).seqP;
        seqD = ms1(c).fit_type3(bestInds).seqD;
        resP = ms1(c).fit_type3(bestInds).startResP;
        resD = ms1(c).fit_type3(bestInds).startResD;
        linkP = ms1(c).fit_type3(bestInds).XlinkP;
        linkD = ms1(c).fit_type3(bestInds).XlinkD;
        ID_P = ms1(c).fit_type3(bestInds).ID_P;
        ID_D = ms1(c).fit_type3(bestInds).ID_D;
        score = ms1(c).fit_type3(bestInds).score;
        ppm = ms1(c).fit_type3(bestInds).ppm;
        ch = ms1(c).ch;
        trueMass = ms1(c).trueMass;
        relScore = score/(length(seqP)+(length(seqD)+1)/2);
        intens = ms1(c).Ims2;
        duplicateInd = findEnteryInReport(report,seqP,seqD);
        if (relScore > ms2RelScoreTH)
            if (isempty(duplicateInd))
                reportCounter = reportCounter + 1;
                report(reportCounter).seqP = seqP;
                report(reportCounter).seqD = seqD;
                report(reportCounter).resP = resP;
                report(reportCounter).resD = resD;
                report(reportCounter).ID_P = ID_P;
                report(reportCounter).ID_D = ID_D;
                report(reportCounter).linkP = linkP;
                report(reportCounter).linkD = linkD;
                report(reportCounter).score = score;
                report(reportCounter).relScore = relScore;
                report(reportCounter).ppm = ppm;
                report(reportCounter).intens = intens;
                report(reportCounter).ch = ch;
                report(reportCounter).trueMass = trueMass;
                report(reportCounter).ms1ind = c;
                report(reportCounter).ms1subInd = bestInds;
            else
                if ((score>report(duplicateInd).score) | ...
                        ((score==report(duplicateInd).score) & (intens>=report(duplicateInd).intens)))
                    report(duplicateInd).seqP = seqP;
                    report(duplicateInd).seqD = seqD;
                    report(duplicateInd).resP = resP;
                    report(duplicateInd).resD = resD;
                    report(duplicateInd).ID_P = ID_P;
                    report(duplicateInd).ID_D = ID_D;
                    report(duplicateInd).linkP = linkP;
                    report(duplicateInd).linkD = linkD;
                    report(duplicateInd).score = score;
                    report(duplicateInd).relScore = relScore;
                    report(duplicateInd).ppm = ppm;
                    report(duplicateInd).intens = intens;
                    report(duplicateInd).ch = ch;
                    report(duplicateInd).trueMass = trueMass;
                    report(duplicateInd).ms1ind = c;
                    report(duplicateInd).ms1subInd = bestInds;
                end
            end
        end
    end
end

