function trueMassList = getTrueMasses(spectrum);
% get these values from the masses.m
global c13P ProtonMass daPerRes cPerRes c13Delta
global maxChargeState takePeaksTill maxNshifts maxC13Isotope minimalIsotopeFractionToConsider mustFindIntensityPercent fragmantationMassTol

assigned = zeros(length(spectrum(:,1)),1);
trueMassList = [];
isotopeRange = 0:maxC13Isotope;

% Sorting the peak intensities
[IPeak,IPeakInd] = sort(spectrum(:,2),'descend');

% Analysing the peaks in decreasing order
for c=1:ceil(takePeaksTill*length(IPeakInd(:))) %take top 0.7 percentile peaks for identification, not going to be suitable for crosslinks
    workInd = IPeakInd(c); %the index of the top 0.7 ions
    if (~assigned(workInd))
        bestScore = Inf;
        bestCharge = -1;
        bestMaxPos = -1;
        bestAr = [];
        for chargeState=1:maxChargeState
            trueMass = spectrum(workInd,1)*chargeState-ProtonMass*chargeState;
            estCarbonN = trueMass/23.7; %estimate the carbon numbers of the ion
            carbonDis = (estCarbonN*c13P).^isotopeRange ./ factorial(isotopeRange) * exp(-estCarbonN*c13P);
            maxCarbonDis = max(carbonDis);
            [carbonDisVals,carbonDisInds] = sort(carbonDis,'descend');
            if (carbonDisVals(maxNshifts)>minimalIsotopeFractionToConsider)
                dynamicMaxNshifts = maxNshifts;
            else
                dynamicMaxNshifts = 1;
            end
            for whoIsMax = 1:dynamicMaxNshifts
                intensArray = [];
                dealBreaker = 0;
                score = 0;
                for isotopeInd = 1:length(isotopeRange)
                    if (carbonDis(isotopeInd)>minimalIsotopeFractionToConsider)
                        deltaC13 = isotopeRange(isotopeInd)-isotopeRange(carbonDisInds(whoIsMax));
                        lookForMZ = (trueMass+deltaC13*c13Delta+ProtonMass*chargeState)/chargeState;
                        [deltsVal,deltInd] = min(abs(spectrum(:,1)-lookForMZ));
                        if (deltsVal/lookForMZ*1e6 < fragmantationMassTol)
                            intensArray = [intensArray;[isotopeInd,spectrum(deltInd,2),spectrum(deltInd,1),deltInd]];
                        else
                            if (carbonDis(isotopeInd)/maxCarbonDis > mustFindIntensityPercent)
                                dealBreaker = 1;
                            end
                            if (~isempty(intensArray))
                                break
                            end
                        end
                    end
                end
                intensityConstant = sqrt((carbonDis(intensArray(:,1)).^2)'\(intensArray(:,2).^2));
                for ind = 1:length(intensArray(:,1))
                    predictedI = carbonDis(intensArray(ind,1))*intensityConstant;
                    actualI = intensArray(ind,2);
                    relVal = 2*abs(actualI-predictedI)/(actualI+predictedI);
                    score = score + relVal - 2/3;
                end
                if (~dealBreaker & (length(intensArray(:,1))>1) & (bestScore>score))
                    bestScore = score;
                    bestCharge = chargeState;
                    bestMaxPos = isotopeRange(carbonDisInds(whoIsMax));
                    bestAr = intensArray;
                end
            end
        end
        if (isempty(bestAr))
            monoIsotopicMass = spectrum(workInd,1)-ProtonMass;
            trueMassList = [trueMassList ; [monoIsotopicMass , monoIsotopicMass , -1 , spectrum(workInd,2) , bestScore]];
            assigned(workInd) = 1;
        else
            Is = bestAr(:,2);
            ch = bestCharge;
            xs = Is/ch;
            ys = Is.*(bestAr(:,3) - isotopeRange(bestAr(:,1))'*c13Delta/ch - ProtonMass);
            monoIsotopicMass = xs\ys;
            trueMassList = [trueMassList ; [monoIsotopicMass , spectrum(workInd,1)*ch-ProtonMass*ch , ch , spectrum(workInd,2) , bestScore]];
            assigned(bestAr(:,4)) = 1;
        end
    end
end

                

