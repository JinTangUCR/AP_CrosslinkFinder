close all
clear all
pack

% -------------------------------------------------
% don't forget to turn the offsets in 'masses' to 0
% -------------------------------------------------

% The offsets will be calculated only on high intensity peaks.
% the digestion includes only Met-oxy and Tris-BS3
minimalIntensity = 2000;
ms2th = 0.7;

masses;
% [ms1,allSpectra,massList] = readMGF('110322_NKalisman_POLII_closed_180min_3+.mgf');
load PIC_close_2011_03_22   

ms1List = zeros(length(ms1),1);
intensityVec = zeros(length(ms1),1);
for c=1:length(ms1)
    ms1List(c) = ms1(c).trueMass;   
    intensityVec(c) = ms1(c).Ims2;
end
% error('gfdgs')
% Assigning peptides with modifications, but not cross linked.
digestion;
fprintf(1,'Number of possible peptides: %.0f\n',length(digest))
digestM1 = zeros(length(digest),1);
for c=1:length(digest)
    digestM1(c) = sum(peptide2masses(digest(c).seq)) + waterMass;
end    
for c=1:length(ms1List)
    matchingInds = find(abs(ms1List(c) - digestM1)/ms1List(c)*1e6 < ms1PreCalbFit);
    for indC = 1:length(matchingInds)
        ms1(c).matches(indC).type = 1;
        ms1(c).matches(indC).ppm = (ms1List(c) - digestM1(matchingInds(indC)))/ms1List(c)*1e6;
        ms1(c).matches(indC).seq = digest(matchingInds(indC)).seq;
        ms1(c).matches(indC).startRes = digest(matchingInds(indC)).startRes;
        allMass = massList(ms1(c).startTrueMassInd:ms1(c).endTrueMassInd,:);
        [bScore,yScore,ppms] = scoreMS2linearPep(allMass, ms1(c).matches(indC).seq , 0 , 0);
        ms1(c).matches(indC).bScore = bScore;
        ms1(c).matches(indC).yScore = yScore;
        ms1(c).matches(indC).ppm2 =  ppms;
    end
end
    
% % use the following commented lines to find MS2 score cutoff for
% % calculating the offsets.
% ms2Scores = [];
% for c=1:length(ms1List)
%     for matchC=1:length(ms1(c).matches)
%         tmpScore = ms1(c).matches(matchC).bScore+ms1(c).matches(matchC).yScore;
%         len = length(ms1(c).matches(matchC).seq);
%         ms2Scores = [ms2Scores ; [tmpScore , tmpScore/len]];
%     end
% end


ms1shifts = [];
ms2shifts = [];
VtrueMass = [];
Vch = [];
Vppm = [];
Vints = [];
for c=1:length(ms1List)
    for matchC=1:length(ms1(c).matches)
        tmpScore = ms1(c).matches(matchC).bScore+ms1(c).matches(matchC).yScore;
        len = length(ms1(c).matches(matchC).seq);
        if ((tmpScore/len > ms2th) & (ms1(c).Ims2>minimalIntensity))
            ms1shifts = [ms1shifts,ms1(c).matches(matchC).ppm];
            ms2shifts = [ms2shifts;ms1(c).matches(matchC).ppm2];            
            VtrueMass = [VtrueMass,ms1(c).trueMass];
            Vch = [Vch,ms1(c).ch];
            Vppm = [Vppm,ms1(c).matches(matchC).ppm];
            Vints = [Vints,ms1(c).Ims2];
%             % Uncomment this if you want to see the MS2 assignment
%             if (abs(ms1(c).matches(matchC).ppm-3)>4)
%             spectrum = allSpectra(ms1(c).startMS2ind:ms1(c).endMS2ind,:);
%             [bScore,yScore,ppms] = scoreMS2linearPep(spectrum, ms1(c).matches(matchC).seq , 0 , 1);
%             [ms1(c).matches(matchC).ppm , ms1(c).trueMass , ms1(c).ch , ms1(c).Ims2]
%             pause
%             end
        end
    end
end

figure(1),hist(ms1shifts(:),-15:0.5:15)
figure(1),title('The MS1 shifts')
median(ms1shifts)
figure(2),hist(ms2shifts(:,1),-21:0.5:21)
figure(2),title('The MS2 shifts')
median(ms2shifts(:,1))

    

