function bSeries = getBseries(pep)

bSeries = [];
for c=1:(length(pep)-1)
    bSeries = [bSeries , sum(pep(1:c))]; % all b ions
end
