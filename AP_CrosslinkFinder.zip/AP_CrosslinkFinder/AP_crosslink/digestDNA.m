% Reading the DNA sequences
fid = fopen(dnaFileName,'rt'); 
seqCounter = 0;
lin = fgetl(fid);
while (ischar(lin))
    if (lin(1)=='>')
        seqCounter = seqCounter + 1;
        seqs(seqCounter).description = lin;
        seqs(seqCounter).seq = [];
        if (seqCounter>1)
            fprintf('Read sequence %s \n%s\n',seqs(seqCounter-1).description,seqs(seqCounter-1).seq);
        end
    else
        seqs(seqCounter).seq = [seqs(seqCounter).seq , deblank(lin)];
    end
    lin = fgetl(fid);
end
fclose(fid);
fprintf('Read sequence %s \n%s\n',seqs(seqCounter).description,seqs(seqCounter).seq);
% Starting in-silico digestion
dna_digest = [];

for dnaNumber = 1:length(seqs)
    seq = seqs(dnaNumber).seq; % assign DNA sequence to seq and perform the digestion one sequence by one sequence
    apInds = strfind(seq,'X'); % all indexes idicating AP site
    for cutStartInd = (apInds-5):2:(apInds-1) % index the cut number
        for cutEndInd = apInds:1:(apInds+4) % issue here---
            initialDigest = seq((cutStartInd+1):(cutEndInd));
            finalDigest = initialDigest;
            for seqC = 1:length(finalDigest(:,1))
                if (length(deblank(finalDigest(seqC,:)))>=1)
                    addInd = length(dna_digest)+1;
                    dna_digest(addInd).seq = deblank(finalDigest(seqC,:)); % remove trailing blanks
                    dna_digest(addInd).startRes = cutStartInd+1;
                    dna_digest(addInd).dna = dnaNumber;
                end
            end
        end
    end
end
return