function [PScore,DScore,ppms] = scoreMS2externalXL(trueMassList,seqP,wholeMassP,bSeriesP,ySeriesP,seqD,wholeMassD,cSeriesD,wSeriesD,AminusB_Series,...
    linkP,linkD,toPrint) 

global ms2PostCalbFit ms2offset crosslinkshift waterMass
global adenine thymine cytosine guanine uracil

%Extracting the masslist from data
monoIsotopicMasses = trueMassList(:,1);
assigned = zeros(length(monoIsotopicMasses),1);

PScore = 0;%output1
DScore = 0;%output2
ppms = [];%output3
%peptide fragments
bScoreP = 0;
yScoreP = 0;
%DNA fragments
cScoreD = 0;
wScoreD = 0;
AminusB_ScoreD =0;

% Generate the crosslink mass list


%b-ion and intact dna crosslink
bd_XL = bSeriesP(linkP:(length(seqP)-1)) + wholeMassD-crosslinkshift;
%y-ion and intact dna crosslink
yd_XL = ySeriesP(1:(linkP-1)) + wholeMassD - crosslinkshift;


% b-ions with dna fragments

% b-ions and c-ions crosslink
% y-ions and c-ions crosslink
bc_XL = [];
yc_XL = [];
if linkD < length(seqD)
   for c = linkD:(length(seqD)-1)
        bc_XL_1 = bSeriesP(linkP:(length(seqP)-1))+cSeriesD(c)-crosslinkshift;
        yc_XL_1 = ySeriesP(1:(linkP-1))+cSeriesD(c)-crosslinkshift;
        bc_XL = [bc_XL,bc_XL_1];
        yc_XL = [yc_XL,yc_XL_1];
   end
   %b-ions and c plus water ions
   bc_pluswater = bc_XL+waterMass;
   yc_pluswater = yc_XL+waterMass;
end

%b-ions and a-B ions
%y-ions and a-B ions
ba_XL = [];
ya_XL = [];
if linkD==length(seqD)
    %When the AP site is at the 3'-term of DNA
    %only try to search the loss of one closest base group to the AP site
    if linkD>2
       if seqD(linkD-2)=='A' ||seqD(linkD-2) =='a'
          ba_XL= bSeriesP(linkP:(length(seqP)-1))+ wholeMassD-crosslinkshift-adenine; % only calculate the lose of base
          ya_XL = ySeriesP(1:(linkP-1))+wholeMassD-crosslinkshift-adenine;
       end
       if seqD(linkD-2)=='T' 
          ba_XL= bSeriesP(linkP:(length(seqP)-1))+ wholeMassD-crosslinkshift-thymine;
          ya_XL = ySeriesP(1:(linkP-1))+wholeMassD-crosslinkshift-thymine;
       end
       if seqD(linkD-2)=='u'
          ba_XL= bSeriesP(linkP:(length(seqP)-1))+ wholeMassD-crosslinkshift-uracil;
          ya_XL = ySeriesP(1:(linkP-1))+wholeMassD-crosslinkshift-uracil;
       end
       if seqD(linkD-2)=='C' ||seqD(linkD-2) =='c'
          ba_XL= bSeriesP(linkP:(length(seqP)-1))+ wholeMassD-crosslinkshift-cytosine;
          ya_XL = ySeriesP(1:(linkP-1))+wholeMassD-crosslinkshift-cytosine;
       end
       if seqD(linkD-2)=='G' ||seqD(linkD-2) =='g'
          ba_XL= bSeriesP(linkP:(length(seqP)-1))+ wholeMassD-crosslinkshift-guanine;
          ya_XL = ySeriesP(1:(linkP-1))+wholeMassD-crosslinkshift-guanine;
       end
    end
    % When the AP site is the only residue crosslinked, it is in the case
    % of crosslink with intact DNA.
else
    % When there are other nucleosides on the 3' side of AP site, the a-B
    % ion is calculated
    for c = ((linkD+1)/2):length(AminusB_Series)
        ba_XL_1 = bSeriesP(linkP:(length(seqP)-1)) + AminusB_Series(c)-crosslinkshift;
        ya_XL_1 = ySeriesP(1:(linkP-1)) + AminusB_Series(c)-crosslinkshift;
        ba_XL = [ba_XL,ba_XL_1];
        ya_XL = [ya_XL,ya_XL_1];
    end
end

%b-ions and w ions
%y-ions and w ions
bw_XL = [];
yw_XL = [];
if linkD==1
    % When the AP site is on the 5'-term or the sequence is 'X'
    bw_XL = [];
    yw_XL = [];
else
    for c = 1:(linkD-1)
        bw_XL_1 = bSeriesP(linkP:(length(seqP)-1)) + wSeriesD(c)-crosslinkshift;
        yw_XL_1 = ySeriesP(1:(linkP-1))+wSeriesD(c)-crosslinkshift;
        bw_XL = [bw_XL,bw_XL_1];
        yw_XL = [yw_XL,bw_XL_1];
    end
    %calculate the w series minus water
    bw_minuswater = bw_XL-waterMass;
    yw_minuswater = yw_XL-waterMass;
end

% Perform search in the ion list

% Check the b series
%Check the b ions don't contain crosslinkinf site (1:(linkP-1))
for c = 1: (linkP-1)
    desiredMass = bSeriesP(c);
    foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
    if (~isempty(foundInd))
       assigned(foundInd) =1;
       bScoreP = bScoreP +1;
       ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6-ms2offset, desiredMass]];
       if (toPrint)
           fprintf(1,'b');
       end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
%Check the b ions crosslinked with DNA
%first check when the DNA is intact
for c= 1:length(bd_XL)
    desiredMass = bd_XL(c);
    foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
    if (~isempty(foundInd))
       assigned(foundInd) =1;
       bScoreP = bScoreP +1;
       ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
       if (toPrint)
           fprintf(1,'d');
       end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
if (toPrint) % print peptide sequence
    fprintf(1,[' \n%s' '       ' 'Crosslink Residue: ' '%s' '%d\n'],seqP,seqP(linkP),linkP);
end
%Check the y ions crosslinked with DNA
% first check when the DNA is intact
for c = 1:length(yd_XL)
    foundInd = find(abs((monoIsotopicMasses-yd_XL(c))/yd_XL(c)*1e6)<ms2PostCalbFit);
    if (~isempty(foundInd))
        assigned(foundInd) = 1;
        yScoreP = yScoreP +1;
        ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-yd_XL(c))/yd_XL(c)*1e6, yd_XL(c)]];
        if(toPrint)
            fprintf(1,'d');
        end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
%Check the y ions don't contain crosslinking site
for c = linkP:(length(seqP)-1)
    desiredMass = ySeriesP(c);
    foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
    if (~isempty(foundInd))
        assigned(foundInd) = 1;
        yScoreP = yScoreP +1;
        ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
        if (toPrint)
            fprintf(1,'y')
        end
    else
        if (toPrint)
            fprintf(1,' ')
        end
    end
end
if (toPrint)
    fprintf(1,[' \n%s' '         Crosslink Residue: ' 'AP%d\n\n '],seqD,linkD);
end

%For DNA
%find c-series crosslink with y and b ions
%if the X is on the 5'side, linkD=1 
if ~(linkD==1)
    for c=1:(linkD-1)
    desiredMass = cSeriesD(c);
    foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
       if (~isempty(foundInd))
           assigned(foundInd) =1;
           cScoreD = cScoreD+1;
           ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
       end
    end
    if linkD == length(seqD)
        %The fragment ion have intact DNA to crosslink with the peptide fragments,the mass 
        %is the peptide fragments plus the mass of DNA, these ions has been
        %searched before.
    else
        %linkD<length(seqD), these fragment crosslinked c-ions are in the
        %bc_XL and yc_xL, bc_pluswater and yc_pluswater
        if (~isempty(bc_XL))
            for c = 1:length(bc_XL) % b ions
                foundIndc = find(abs((monoIsotopicMasses-bc_XL(c))/bc_XL(c)*1e6)<ms2PostCalbFit);
                foundIndcw = find(abs((monoIsotopicMasses-bc_pluswater(c))/bc_pluswater(c)*1e6)<ms2PostCalbFit);
                if (~isempty(foundIndc))||(~isempty(foundIndcw))
                    cScoreD = cScoreD +1;
                    if (~isempty(foundIndc))
                       assigned(foundIndc) =1;
                       ppms = [ppms ; [(monoIsotopicMasses(foundIndc(1))-bc_XL(c))/bc_XL(c)*1e6, bc_XL(c)]];
                    end
                    if (~isempty(foundIndcw))
                       assigned(foundIndcw) = 1;
                       ppms = [ppms; [(monoIsotopicMasses(foundIndcw(1))-bc_pluswater(c))/bc_pluswater(c)*1e6,bc_pluswater(c)]];
                    end
                end
            end
        end
        if (~isempty(yc_XL))
            for c = 1: length(yc_XL) % y ions
                foundIndc = find(abs((monoIsotopicMasses-yc_XL(c))/yc_XL(c)*1e6)<ms2PostCalbFit);
                foundIndcw = find(abs((monoIsotopicMasses-yc_pluswater(c))/yc_pluswater(c)*1e6)<ms2PostCalbFit);
                if (~isempty(foundIndc))||(~isempty(foundIndcw))
                    cScoreD = cScoreD +1;
                    if (~isempty(foundIndc))
                       assigned(foundIndc) =1;
                       ppms = [ppms; [(monoIsotopicMasses(foundIndc(1))-yc_XL(c))/yc_XL(c)*1e6,yc_XL(c)]];
                    end
                    if (~isempty(foundIndcw))
                        assigned(foundIndcw) = 1;
                        ppms = [ppms; [(monoIsotopicMasses(foundIndcw(1))-yc_pluswater(c))/yc_pluswater(c)*1e6,yc_pluswater(c)]];
                    end   
                end  
            end
        end
    end
else %When X is on the 5'side, the c ions are crosslinked with the peptides
    for c = 1:length(bc_XL) % b ions
        foundIndc = find(abs((monoIsotopicMasses-bc_XL(c))/bc_XL(c)*1e6)<ms2PostCalbFit);
        foundIndcw = find(abs((monoIsotopicMasses-bc_pluswater(c))/bc_pluswater(c)*1e6)<ms2PostCalbFit);
       if (~isempty(foundIndc))||(~isempty(foundIndcw))
           cScoreD = cScoreD +1;
           if (~isempty(foundIndc))
              assigned(foundIndc) =1;
              ppms = [ppms; [(monoIsotopicMasses(foundIndc(1))-bc_XL(c))/bc_XL(c)*1e6,bc_XL(c)]];
           end
           if(~isempty(foundIndcw))
              assigned(foundIndcw) = 1;
              ppms = [ppms; [(monoIsotopicMasses(foundIndcw(1))-bc_pluswater(c))/bc_pluswater(c)*1e6,bc_pluswater(c)]];
           end
       end
    end
    for c = 1: length(yc_XL) % y ions
        foundIndc = find(abs((monoIsotopicMasses-yc_XL(c))/yc_XL(c)*1e6)<ms2PostCalbFit);
        foundIndcw = find(abs((monoIsotopicMasses-yc_pluswater(c))/yc_pluswater(c)*1e6)<ms2PostCalbFit);
        if (~isempty(foundIndc))||(~isempty(foundIndcw))
           cScoreD = cScoreD +1;
           if (~isempty(foundIndc))
              assigned(foundIndc) =1;
              ppms = [ppms; [(monoIsotopicMasses(foundIndc(1))-yc_XL(c))/yc_XL(c)*1e6,yc_XL(c)]];
           end
           if(~isempty(foundIndcw))
              assigned(foundIndcw) = 1;
              ppms = [ppms; [(monoIsotopicMasses(foundIndcw(1))-yc_pluswater(c))/yc_pluswater(c)*1e6,yc_pluswater(c)]];
           end
        end
    end
end
if (toPrint)
    fprintf(1,['Number of DNA c and a ions: ' '%d\n'],cScoreD);
end

% find the a-B ions
% When the a-B ions do not contain any peptide crosslink
if ~(linkD==1)
   for  c= 1:(linkD-1)/2
       desiredMass = AminusB_Series(c);
       foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6 )<ms2PostCalbFit);
       if (~isempty(foundInd))
           assigned(foundInd) =1;
           AminusB_ScoreD = AminusB_ScoreD +1;
           ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
       end
   end
   if ~(linkD==length(seqD))
       for c = 1:length(ba_XL)
           desiredMass = ba_XL(c);
           foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
           if (~isempty(foundInd))
               assigned(foundInd) =1;
               AminusB_ScoreD = AminusB_ScoreD+1;
               ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
           end
       end
       for c = 1: length(ya_XL)
           desiredMass = ya_XL(c);
           foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
           if (~isempty(foundInd))
               assigned(foundInd) =1;
               AminusB_ScoreD = AminusB_ScoreD +1;
               ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
           end
       end
   end
else
    for c= 1: length(ba_XL)
        desiredMass = ba_XL(c);
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
        if (~isempty(foundInd))
            assigned(foundInd) =1;
            AminusB_ScoreD = AminusB_ScoreD +1;
            ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
        end
    end
    for c = 1: length(ya_XL)
        desiredMass = ya_XL(c);
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
        if (~isempty(foundInd))
            assigned(foundInd) =1;
            AminusB_ScoreD = AminusB_ScoreD +1;
            ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6, desiredMass]];
        end
    end
end
    
if (toPrint)
    fprintf(1,['Number of DNA a-B ions: ' '%d\n'],AminusB_ScoreD);
end


% Check the W ions
if ~(linkD==length(seqD))
    for c = linkD:(length(seqD)-1)
        desiredMass = wSeriesD(c);
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6)<ms2PostCalbFit);
        if(~isempty(foundInd))
            assigned(foundInd) =1;
            wScoreD = wScoreD + 1;
            ppms = [ppms; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6,desiredMass]];
        end
    end
    if ~(linkD==1)
        for c = 1:length(bw_XL)
            foundIndw = find(abs((monoIsotopicMasses-bw_XL(c))/bw_XL(c)*1e6)<ms2PostCalbFit);
            foundIndww = find(abs((monoIsotopicMasses-bw_minuswater(c))/bw_minuswater(c)*1e6)<ms2PostCalbFit);
            if  (~isempty(foundIndw))||(~isempty(foundIndww))
                wScoreD = wScoreD + 1;
                if (~isempty(foundIndw))
                     assigned(foundIndw) =1;
                     ppms = [ppms; [(monoIsotopicMasses(foundIndw(1))-bw_XL(c))/bw_XL(c)*1e6,bw_XL(c)]];
                end
                if (~isempty(foundIndww))
                    assigned(foundIndww) =1;
                    ppms = [ppms; [(monoIsotopicMasses(foundIndww(1))-bw_minuswater(c))/bw_minuswater(c)*1e6,bw_minuswater(c)]];
                end
            end
        end
        for c = 1:length(yw_XL)
            foundIndw = find(abs((monoIsotopicMasses-yw_XL(c))/yw_XL(c)*1e6)<ms2PostCalbFit);
            foundIndww = find(abs((monoIsotopicMasses-yw_minuswater(c))/yw_minuswater(c)*1e6)<ms2PostCalbFit);
            if  (~isempty(foundIndw))||(~isempty(foundIndww))
               wScoreD = wScoreD + 1;
                if (~isempty(foundIndw))
                     assigned(foundIndw) =1;
                     ppms = [ppms; [(monoIsotopicMasses(foundIndw(1))-yw_XL(c))/yw_XL(c)*1e6,yw_XL(c)]];
                end
                if (~isempty(foundIndww))
                    assigned(foundIndww) =1;
                    ppms = [ppms; [(monoIsotopicMasses(foundIndww(1))-yw_minuswater(c))/yw_minuswater(c)*1e6,yw_minuswater(c)]];
                end
            end
        end
    end
else
    for c = 1:length(bw_XL)
        foundIndw = find(abs((monoIsotopicMasses-bw_XL(c))/bw_XL(c)*1e6)<ms2PostCalbFit);
        foundIndww = find(abs((monoIsotopicMasses-bw_minuswater(c))/bw_minuswater(c)*1e6)<ms2PostCalbFit);
        if  (~isempty(foundIndw))||(~isempty(foundIndww))
                wScoreD = wScoreD + 1;
                if (~isempty(foundIndw))
                     assigned(foundIndw) =1;
                     ppms = [ppms; [(monoIsotopicMasses(foundIndw(1))-bw_XL(c))/bw_XL(c)*1e6,bw_XL(c)]];
                end
                if (~isempty(foundIndww))
                    assigned(foundIndww) =1;
                    ppms = [ppms; [(monoIsotopicMasses(foundIndww(1))-bw_minuswater(c))/bw_minuswater(c)*1e6,bw_minuswater(c)]];
                end
        end
    end
    for c = 1:length(yw_XL)
            foundIndw = find(abs((monoIsotopicMasses-yw_XL(c))/yw_XL(c)*1e6)<ms2PostCalbFit);
            foundIndww = find(abs((monoIsotopicMasses-yw_minuswater(c))/yw_minuswater(c)*1e6)<ms2PostCalbFit);
            if  (~isempty(foundIndw))||(~isempty(foundIndww))
               wScoreD = wScoreD + 1;
                if (~isempty(foundIndw))
                     assigned(foundIndw) =1;
                     ppms = [ppms; [(monoIsotopicMasses(foundIndw(1))-yw_XL(c))/yw_XL(c)*1e6,yw_XL(c)]];
                end
                if (~isempty(foundIndww))
                    assigned(foundIndww) =1;
                    ppms = [ppms; [(monoIsotopicMasses(foundIndww(1))-yw_minuswater(c))/yw_minuswater(c)*1e6,yw_minuswater(c)]];
                end
            end
    end
end
          
if (toPrint)
    fprintf(1,['Number of DNA w and y ions: ' '%d\n'],wScoreD);
end           


PScore = yScoreP + bScoreP;
DScore = cScoreD + wScoreD + AminusB_ScoreD;

if (toPrint)
    close all
    plot(trueMassList(:,1)./abs(trueMassList(:,3)),trueMassList(:,4),'k.',...
        trueMassList(find(assigned),1)./abs(trueMassList(find(assigned),3)),trueMassList(find(assigned),4),'r.')
end
