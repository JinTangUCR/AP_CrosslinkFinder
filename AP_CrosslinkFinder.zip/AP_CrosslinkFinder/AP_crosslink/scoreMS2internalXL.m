function [bScore,yScore,ppms] = scoreMS2internalXL(trueMassList,seq,linkA,linkB,postCalb,toPrint) 

global ms2PreCalbFit ms2PostCalbFit ms2offset waterMass

if (postCalb)
    tol = ms2PostCalbFit;
else
    tol = ms2PreCalbFit;
end

monoIsotopicMasses = trueMassList(:,1);
assigned = zeros(length(monoIsotopicMasses),1);
bScore = 0;
yScore = 0;
ppms = [];
pepMasses = peptide2masses(seq);
wholeMass = sum(pepMasses) + waterMass;

bSeries = getBseries(pepMasses);
bSeries(linkA:(linkB-1)) = wholeMass;
for c=1:length(bSeries)
    desiredMass = bSeries(c);
    if (desiredMass>0) % not doing N-terminal Zs
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6 - ms2offset)<tol);
    else
        foundInd = [];
    end
    assigned(foundInd) = 1;
    if (~isempty(foundInd))
        bScore = bScore + 1;
        ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6 - ms2offset, desiredMass]];
        if (toPrint)
            fprintf(1,'b');
        end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
if (toPrint)
    fprintf(1,' \n%s|%s|%s\n ',seq(1:(linkA-1)),seq((linkA+1):(linkB-1)),seq((linkB+1):end));
end
ySeries = getYseries(pepMasses);
ySeries(linkA:(linkB-1)) = wholeMass;
for c=1:length(ySeries)
    desiredMass = ySeries(c);
    if (desiredMass>0) % not doing N-terminal Zs
        foundInd = find(abs((monoIsotopicMasses-desiredMass)/desiredMass*1e6 - ms2offset)<tol);
    else
        foundInd = [];
    end
    assigned(foundInd) = 1;
    if (~isempty(foundInd))
        yScore = yScore + 1;
        ppms = [ppms ; [(monoIsotopicMasses(foundInd(1))-desiredMass)/desiredMass*1e6 - ms2offset, desiredMass]];
        if (toPrint)
            fprintf(1,'y');
        end
    else
        if (toPrint)
            fprintf(1,' ');
        end
    end
end
if (toPrint)
    fprintf(1,'\n\n');
end

if (toPrint)
    close all
    plot(trueMassList(:,1)./abs(trueMassList(:,3)),trueMassList(:,4),'k.',...
        trueMassList(find(assigned),1)./abs(trueMassList(find(assigned),3)),trueMassList(find(assigned),4),'r.')
end
