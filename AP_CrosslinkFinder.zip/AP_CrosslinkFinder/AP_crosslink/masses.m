global abn carbons nitros oxygen solfur aaMass naMass cPerRes nPerRes oPerRes sPerRes
global daPerRes c13P n15p o18p s34p c13Delta ProtonMass waterMass 
global ms1PreCalbFit ms2PreCalbFit ms1PostCalbFit ms2PostCalbFit  ms1offset ms2offset
global maxChargeState takePeaksTill maxNshifts maxC13Isotope minimalIsotopeFractionToConsider mustFindIntensityPercent fragmantationMassTol
global miscleave minPepLength 
global ms2RelScoreTH minBYnumToShow
global phosphoryl crosslinkshift
global adenine thymine cytosine guanine uracil

abn = 0.01* [7.49,1.86,5.22,6.26,3.91, 7.1,2.23,5.45,5.82,9.06, 2.27, 4.53 ,5.12,4.11,5.22,7.34, 5.96,6.48,1.32,3.25];
carbons = [3,3,4,5,9,2,6,6,6,6,5,4,5,5,6,3,4,5,11,9]; %C in 20 amino acids
nitros =  [1,1,1,1,1,1,3,1,2,1,1,2,1,2,4,1,1,1,2,1]; %N in 20 amino acids 
oxygen =  [1,1,3,3,1,1,1,1,1,1,1,2,1,2,1,2,2,1,1,2]; % O in 20 amino acids
solfur =  [0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0]; % S in 20 animo acids
aaMass = [	71.037114 % A amino acid mass -18
    		174.04628 % C = Cystine with proponamide modification  , change  to 85.13880
    		115.02694 % D
    		129.04259 % E 
    		147.06841 % F
    		57.021464 % G
    		137.05891 % H
    		113.08406 % I
    		128.09496 % K
    		113.08406 % L
    		131.04048 % M
    		114.04293 % N
    		97.052764 % P
    		128.05858 % Q
    		156.10111 % R
    		87.032028 % S
    		101.04768 % T
    		99.068414 % V
    		186.07931 % W
    		163.06333 % Y
            147.03540 % O = Oxidized Methionin
            190.07931; % J = Tryptophan oxidation +4  
            202.07931 % U = Tryptophan oxidation +16
            206.07931 % Z = Tryptophan oxidation +20
            218.07931 % z = Tryptophan oxidation +32
            169.0129118 % s = phosphoralated serine
            43.008565 % t = phosphoralated threonine
            170.105525]'; % k = acytelated N6-lysine
 naMass = [ 233.09127 % A, mass of 
    		224.07971 % T
    		209.08004 % C
    		249.11371 % G 
    		116.04734 % X 116 for AP site, 98 for beta elimination, 80 for mass shift of 82
    		249.08619 % a
    		226.05897 % u
    		225.07496 % c
    		265.08110 % g
    		98.03678 % x
            79.96633]'; % P: H3PO4-H2O, phophoryl
% mass of nucleobases
adenine = 135.054493;
thymine = 126.042926;
cytosine = 111.04326;
guanine = 151.049408;
uracil = 112.0272764;

cPerRes = 4.94;
nPerRes = 1.36;
oPerRes = 1.48;
sPerRes = 0.04;
daPerRes = 112.47;
c13P = 0.0111;
n15p = 0.0037;
o18p = 0.0020;  % +2 mass
s34p = 0.0420;  % +2 mass
c13Delta = 1.003354838;
ProtonMass = 1.0072764;
waterMass = 18.01057;
crosslinkshift = 15.994915; % the formation of crosslink caused the net mass shift of the dna and protein (decrease)
phosphoryl = 79.96633; %PO3H

% For peak assignment
ms1PreCalbFit = 15; %ppm
ms2PreCalbFit = 300; %ppm
ms1PostCalbFit = 10; %ppm
ms2PostCalbFit = 300; %ppm
ms1offset = 0.0;  %ppm  Calculated on the single peptides in XL mix


% for MS2 interpretation
maxChargeState = 3; % The maximal charge state to check in the fragmentation.
takePeaksTill = 1; % top 20% percentile ; 0.5 - median etc...
maxNshifts = 2; % Possible ambiguity about what is the maximal peak. I think this number should be 2 unless the masses are >5000 Da
maxC13Isotope = 3; % How far to calculate the isotope series. I think this number should be 3 unless the masses are >5000 Da
minimalIsotopeFractionToConsider = 0.05;
mustFindIntensityPercent = 0.8; % If you see the most intense peak, you should also see others who are at least this fraction of the most intense.
fragmantationMassTol = 8; % in ppm. For the purpose of finding charge state

% digestion parameters
miscleave = 4;
minPepLength = 2;

% For reporting
ms2RelScoreTH = 0.25;
minBYnumToShow = 5;

