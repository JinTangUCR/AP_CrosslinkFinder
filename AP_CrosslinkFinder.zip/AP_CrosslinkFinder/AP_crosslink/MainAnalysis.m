% Parameters not in MASSES.m:
% ---------------------------
massPeakArrayResolution = 0.1; % in Da for preindexing MS1
minBYscoreToInclude = 5; % The minimum number of BY fragments needed to include a digest pair in an MS1 entry

[ms1,allSpectra,massList] = readMGF(MGFname);

% Sorting MS1 and taking care of the offset
numOfMS1 = length(ms1);
ms1List = zeros(numOfMS1,1);
for c=1:numOfMS1
    ms1List(c) = ms1(c).trueMass - ms1(c).trueMass*ms1offset*1e-6;    
    ms1(c).fit_type1 = [];
    ms1(c).fit_type2 = [];
    ms1(c).fit_type3 = [];
end
tmpMS1 = ms1;
[sortedMS1,inds] = sort(ms1List,'ascend');
ms1List = sortedMS1;
maxMS1mass = sortedMS1(end) + 20*massPeakArrayResolution;
minMS1mass = sortedMS1(1) - 20*massPeakArrayResolution;
for c=1:numOfMS1
    tmpMS1(c) = ms1(inds(c));
end
ms1 = tmpMS1;
clear tmpMS1

% indexing the mass peaks database
ms1Index = zeros(ceil(maxMS1mass*(1/massPeakArrayResolution)),2); %Round to the nearest integer that is bigger (upper bin)
for c=1:numOfMS1
    indexedTrueM = round(ms1(c).trueMass/massPeakArrayResolution);
    if (ms1Index(indexedTrueM,1)==0)
        ms1Index(indexedTrueM,1) = c;
        ms1Index(indexedTrueM,2) = c;
    else
        ms1Index(indexedTrueM,2) = c;
    end
end

% Precalculating values for digestion of protein and DNA
digestprotein;
digestDNA;
digestP1 = zeros(length(protein_digest),1);
for c=1:length(protein_digest)
    digestP1(c) = sum(peptide2masses(protein_digest(c).seq)) + waterMass;
    pepMasses = peptide2masses(protein_digest(c).seq);
    wholeMass = digestP1(c);
    bSeries = getBseries(pepMasses);
    ySeries = getYseries(pepMasses);
    protein_digest(c).wholeMass = wholeMass;
    protein_digest(c).bSeries = bSeries;    
    protein_digest(c).ySeries = ySeries;
end

% get the mass of DNA fragment ions, here include w,y c and a-B ions, mass
% of each type of need to check with other softwares (hydrogen adduct
% or lost, causing mass deviation by +-1.
% There are at least 5 types of ions are going to generate for DNA
% fragmentation, c, y, w, a and a-B, also it has loss of water, which is more
% fragment ions than peptide.
%Here I combines the y and w ions into W_Series, the a and c ions into
%C_Series. The loss of water is calculated by substracting/adding the
%W_Series/C_Series with waterMass.
digestD1 = zeros(length(dna_digest),1);
for c=1:length(dna_digest)
    digestD1(c) = sum(nucleacid2masses(dna_digest(c).seq)) + waterMass; % mass of the DNA
    nucaMasses = nucleacid2masses(dna_digest(c).seq); % mass of idividual nucleic acid in the sequence (array)
    wholeMass = digestD1(c);
    if (1) %if want to identify y and w ions (differ by one phosphate group)  
        W_Series = get_W_series(nucaMasses);
        dna_digest(c).W_Series = W_Series;
    end
    if (1) %The loss of water is pretty common in DNA fragmentation, to include it into the W series
        %The loss of water has higher intensity than WSeries
        W_Series_minuswater = get_W_series(nucaMasses)-waterMass;
        dna_digest(c).W_Series_minuswater = W_Series_minuswater;
    end
    if (1) % if want to identify C ions
        C_Series = get_C_series(nucaMasses);
        dna_digest(c).C_Series = C_Series;
    end
    if (1) % the C series +water is common fragment
        C_Series_pluswater = get_C_series(nucaMasses)+waterMass;
        dna_digest(c).C_Series_pluswater = C_Series_pluswater;
    end
    if (1) % if want to identify a-B ions
        AminusB_Series = get_AminusB_Series(nucaMasses,dna_digest(c).seq);
        dna_digest(c).AminusB_Series = AminusB_Series;
    end
    dna_digest(c).wholeMass = wholeMass;
end


% Assigning peptides with modifications, but not cross linked.
fprintf(1,'Number of possible peptides and crosslinks: %.0f\n',length(protein_digest))
for B=1:length(ms1List)
    A=0;
    for c = 1:length(digestP1)
        if ~isempty(find(abs((digestP1(c)-ms1List(B))/digestP1(c)*1e6) <= ms1PostCalbFit)); % transfer the mass differences into ppm
           A = A+1;
           ms1(B).fit_type1(A).type =1;
           ms1(B).fit_type1(A).ppm = (digestP1(c)-ms1List(B))/digestP1(c)*1e6;
           ms1(B).fit_type1(A).seq = protein_digest(c).seq;
           ms1(B).fit_type1(A).startRes = protein_digest(c).startRes;
           ms1(B).fit_type1(A).ID = protein_digest(c).ID;
           theMasses = massList(ms1(B).startTrueMassInd:ms1(B).endTrueMassInd,:);
           [bScore,yScore,ppms] = scoreMS2linearPep(theMasses,ms1(B).fit_type1(A).seq,1,0);
           ms1(B).fit_type1(A).score = bScore +yScore;
        end
    end % find the matched MS1 ion and output the index in ms1List (ions in data)
end
    

% Assigning peptides with AP sites cross links.
totalNumberOfXLpairs = length(protein_digest)*(length(dna_digest));
fprintf(1,'Number of possible crosslinks: %.0f\n',totalNumberOfXLpairs)
% looping over all possible cross-links
XLcounter = 0;
for pep_ind=1:length(protein_digest)
    for dna_ind=1:length(dna_digest)
        XLcounter = XLcounter + 1;
        if (mod(XLcounter,10000000)==0)
            fprintf(1,'So far did: %.0f\n',XLcounter); % Minotor the progress
        end 
        xlMass = digestP1(pep_ind)+digestD1(dna_ind)-crosslinkshift; % form the crosslink 
        if ((xlMass<maxMS1mass) & (xlMass>minMS1mass)) % to determine if the search is necessary
            % finding the MS1 range
            indexedTrueM = ceil(xlMass/massPeakArrayResolution); % round into the nearest integer (larger)
            if (ms1Index(indexedTrueM-1,1)==0)%To see if this ion is in the data or not
                %When the lower bin ion is not shown in data
                if (ms1Index(indexedTrueM,1)==0) % check the upper bin
                    %When the upper bin is still not shown in the data
                   toSearch = 0; % Do not perform search
                else
                   %When the upper bin ion is found in the data
                   toSearch = 1; % Perform search
                   lowerMS1ind = ms1Index(indexedTrueM,1);
                   upperMS1ind = ms1Index(indexedTrueM,2); 
                   % lower and upper compare the retention time and scan
                   % number (then search in this range)
                end
            else
                if (ms1Index(indexedTrueM,1)==0)% The lower bin ion is in the data
                   %But the upper bin is not in the data
                   toSearch = 1; %Perform search
                   lowerMS1ind = ms1Index(indexedTrueM-1,1);% Take the index of the lower bin
                   upperMS1ind = ms1Index(indexedTrueM-1,2);
                else
                   toSearch = 1; %Perform search
                   % When both lower bin and upper bin are found in the data
                   lowerMS1ind = ms1Index(indexedTrueM-1,1);
                   upperMS1ind = ms1Index(indexedTrueM,2);
                end
            end
        else toSearch =0;
        end

        if (toSearch) % internal K/R and AP site crosslink
           inds_KR = sort([strfind(protein_digest(pep_ind).seq,'R'),strfind(protein_digest(pep_ind).seq,'K')],'ascend');
           %if (~isempty(find(inds_KR==length(protein_digest(pep_ind).seq)))) %Remove the index of the C-term K
           %   inds_KR(find(inds_KR==length(protein_digest(pep_ind).seq))) = [];
           %end
           inds_X = strfind(dna_digest(dna_ind).seq,'X');
           if (length(inds_KR)>0) % The peptide sequence has intermal K
              %index the MS1 matches
              matchingInds = find(abs((ms1List(lowerMS1ind:upperMS1ind) - xlMass)/xlMass*1e6) < ms1PostCalbFit);
              % Further make sure the mass accuracy to determine the list
              % of ions to seach (matchingInds is a logical array)
              % Out put 1 if the mass is accurate.
              for indC = 1:length(matchingInds) % (looking into all the ions)
                  for KR_Ind = 1:length(inds_KR) % search all K and R in peptide sequence
                      for X_Ind = 1:length(inds_X)% Search all X in dna sequence, usually 1
                          % Extract the MS2 ion list
                          theMasses = massList(ms1(lowerMS1ind+matchingInds(indC)-1).startTrueMassInd:ms1(lowerMS1ind+matchingInds(indC)-1).endTrueMassInd,:);
                          [PScore,DScore,ppms] = scoreMS2externalXL(theMasses, ...
                          protein_digest(pep_ind).seq, protein_digest(pep_ind).wholeMass, protein_digest(pep_ind).bSeries, protein_digest(pep_ind).ySeries, ...
                          dna_digest(dna_ind).seq, dna_digest(dna_ind).wholeMass, dna_digest(dna_ind).C_Series, dna_digest(dna_ind).W_Series, dna_digest(dna_ind).AminusB_Series,...
                          inds_KR(KR_Ind), inds_X(X_Ind), 0);
                          if (PScore + DScore >= minBYscoreToInclude)
                             optionCounter = length(ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3) + 1;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).ppm = ...
                             (ms1List(lowerMS1ind+matchingInds(indC)-1) - xlMass)/xlMass*1e6;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).seqP = protein_digest(pep_ind).seq;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).seqD = dna_digest(dna_ind).seq;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).ID_P = protein_digest(pep_ind).ID;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).ID_D = dna_digest(dna_ind).dna;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).startResP = protein_digest(pep_ind).startRes;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).startResD = dna_digest(dna_ind).startRes;
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).XlinkP = inds_KR(KR_Ind);
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).XlinkD = inds_X(X_Ind);
                             ms1(lowerMS1ind+matchingInds(indC)-1).fit_type3(optionCounter).score = PScore + DScore;
                          end
                       end
                   end
              end
            end
        end
    end
end

% % Ploting the MS1 results
% ppmsT1 = zeros(size(ms1List));
% relMS2scoresT1 = zeros(size(ms1List));
% ppmsT2 = zeros(size(ms1List));
% relMS2scoresT2 = zeros(size(ms1List));
% ppmsT3 = zeros(size(ms1List));
% relMS2scoresT3 = zeros(size(ms1List));
% intens = zeros(size(ms1List));
% for c=1:length(ms1List)
%     intens(c) = ms1(c).Ims2;
%     ppmsT1(c) = 100;
%     relMS2scoresT1(c) = 0;
%     ppmsT2(c) = 100;
%     relMS2scoresT2(c) = 0;
%     ppmsT3(c) = 100;
%     relMS2scoresT3(c) = 0;    
%     for matchC=1:length(ms1(c).fit_type1)
%         if (abs(ms1(c).fit_type1(matchC).ppm)<ppmsT1(c))
%             ppmsT1(c) = abs(ms1(c).fit_type1(matchC).ppm);
%         end
%         if (ms1(c).fit_type1(matchC).score/length(ms1(c).fit_type1(matchC).seq) > relMS2scoresT1(c))
%             relMS2scoresT1(c) = ms1(c).fit_type1(matchC).score/length(ms1(c).fit_type1(matchC).seq);
%         end
%     end
%     for matchC=1:length(ms1(c).fit_type2)
%         if (abs(ms1(c).fit_type2(matchC).ppm)<ppmsT2(c))
%             ppmsT2(c) = abs(ms1(c).fit_type2(matchC).ppm);
%         end
%         if (ms1(c).fit_type2(matchC).score/length(ms1(c).fit_type2(matchC).seq) > relMS2scoresT2(c))
%             relMS2scoresT2(c) = ms1(c).fit_type2(matchC).score/length(ms1(c).fit_type2(matchC).seq);
%         end
%     end
%     for matchC=1:length(ms1(c).fit_type3)
%         if (abs(ms1(c).fit_type3(matchC).ppm)<ppmsT3(c))
%             ppmsT3(c) = abs(ms1(c).fit_type3(matchC).ppm);
%         end
%         if (ms1(c).fit_type3(matchC).score/(length(ms1(c).fit_type3(matchC).seqA)+length(ms1(c).fit_type3(matchC).seqB)) > relMS2scoresT3(c))
%             relMS2scoresT3(c) = ms1(c).fit_type3(matchC).score/(length(ms1(c).fit_type3(matchC).seqA)+length(ms1(c).fit_type3(matchC).seqB));
%         end
%     end
% end
% goodIndT1 = find((ppmsT1<6.1) & (relMS2scoresT1>0.35));
% goodIndT2 = find((ppmsT2<6.1) & (relMS2scoresT2>0.35));
% goodIndT3 = find((ppmsT3<6.1) & (relMS2scoresT3>0.35));
% 
% figure(1),plot(ms1List,intens,'k.',ms1List(goodIndT1),intens(goodIndT1),'r.',ms1List(goodIndT2),intens(goodIndT2),'go',...
%     ms1List(goodIndT3),intens(goodIndT3),'bo')
% figure(2),hist(ppmsT3(goodIndT3),-10:0.5:10)
% 
% for seqC = 1:length(seqs)
%     fprintf('%.0f\n',seqC)
%     allSeq = seqs(seqC).seq;
%     for c=1:length(ms1List)
%         if (~isempty(find(goodIndT1==c)) & (ms1(c).fit_type1(1).gene==seqC))
%             for sind = ms1(c).fit_type1(1).startRes:(ms1(c).fit_type1(1).startRes + length(ms1(c).fit_type1(1).seq) - 1)
%                 allSeq(sind) = '-';
%             end
%         end
%     end
%     fprintf('%s\n',allSeq)
% end
% fprintf('\n\n',allSeq)
% 
% for seqC = 1:length(seqs)
%     fprintf('%.0f\n',seqC)
%     allSeq = seqs(seqC).seq;
%     for c=1:length(ms1List)
%         if (~isempty(find(goodIndT2==c)) & (ms1(c).fit_type2(1).gene==seqC))
%             for sind = ms1(c).fit_type2(1).startRes:(ms1(c).fit_type2(1).startRes + length(ms1(c).fit_type2(1).seq) - 1)
%                 allSeq(sind) = '-';
%             end
%         end
%     end
%     fprintf('%s\n',allSeq)
% end
% fprintf('\n\n',allSeq)
% 
% for seqC = 1:length(seqs)
%     fprintf('%.0f\n',seqC)
%     allSeq = seqs(seqC).seq;
%     for c=1:length(ms1List)
%         if (~isempty(find(goodIndT3==c)) & (ms1(c).fit_type3(1).geneA==seqC))
%             for sind = ms1(c).fit_type3(1).startResA:(ms1(c).fit_type3(1).startResA + length(ms1(c).fit_type3(1).seqA) - 1)
%                 allSeq(sind) = '-';
%             end
%         end
%         if (~isempty(find(goodIndT3==c)) & (ms1(c).fit_type3(1).geneB==seqC))
%             for sind = ms1(c).fit_type3(1).startResB:(ms1(c).fit_type3(1).startResB + length(ms1(c).fit_type3(1).seqB) - 1)
%                 allSeq(sind) = '-';
%             end
%         end
% 
%     end
%     fprintf('%s\n',allSeq)
% end



% % Writing the unassigned peaks to a new MGF file:
% Ith = 2000;
% outputFileName = 'unAssigned.mgf';
% fid = fopen(outputFileName,'wt');
% ionC=0;
% for c=1:length(ms1)
%    if (ms1(c).Ims2>Ith)
%        if (isempty(find(goodIndT1==c)) & isempty(find(goodIndT2==c)) & isempty(find(goodIndT3==c)))
%            writeIonToMGFfile(fid,ms1(c),allSpectra(ms1(c).startMS2ind:ms1(c).endMS2ind,:));
%            ionC = ionC + 1;
%        end
%    end
% end
% fprintf(1,'Wrote %.0f ions to %s\n',ionC,outputFileName);
% fclose(fid);

