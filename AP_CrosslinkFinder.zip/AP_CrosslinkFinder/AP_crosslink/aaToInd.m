function ind = aaToInd(aa)

str = 'ACDEFGHIKLMNPQRSTVWYOJUZzstk';
ind = strfind(str,aa);
if (isempty(ind))
    error(['Unknown amino acid letter: ',aa])
end
