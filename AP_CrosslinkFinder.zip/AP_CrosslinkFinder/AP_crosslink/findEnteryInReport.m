function duplicateInd = findEnteryInReport(report,seqP,seqD)

duplicateInd = [];
for c=1:length(report)
    if ((strcmp(report(c).seqP,seqP) & strcmp(report(c).seqD,seqD)) | ...
        (strcmp(report(c).seqP,seqD) & strcmp(report(c).seqD,seqP)))
        duplicateInd = [duplicateInd , c];
    end
end

    