function filteredReport = filterSiteRedundency(report)

cont = 1;

% Calculating b- and y- scores
Sby = zeros(length(report),1);
for c = 1:length(report)
    [PScore,DScore,ppms] = scoreMS2externalXLStringent(report(c).masses, ...
    report(c).seqP, report(c).seqD,report(c).linkP,report(c).linkD,0);
    Sby(c) = PScore + DScore;
end

notTreated = ones(length(report),1);
toDelete = [];
for c = 1:length(report)
    if (notTreated(c))
        best = c;
        for d = (c+1):length(report)
            if (notTreated(d))
                change = 0;
                if ((((report(c).resP + report(c).linkP - 1) == (report(d).resP + report(d).linkP - 1)) & ...
                        ((report(c).resD + report(c).linkD - 1) == (report(d).resD + report(d).linkD - 1)) & ...
                        (report(c).ID_P == report(d).ID_P) & (report(c).ID_D == report(d).ID_D)) | ...
                        (((report(c).resP + report(c).linkP - 1) == (report(d).resD + report(d).linkD - 1)) & ...
                        ((report(c).resB + report(c).linkD - 1) == (report(d).resP + report(d).linkP - 1)) & ...
                        (report(c).ID_P == report(d).ID_D) & (report(c).ID_D == report(d).ID_P)) ) % same sites
                    if (Sby(best)<Sby(d))
                        change = 1;
                    elseif ((Sby(best)==Sby(d)) & (report(best).intens<report(d).intens))
                        change = 1;
                    end
                    if (change)
                        toDelete = [toDelete,best];
                        best = d;
                    else
                        toDelete = [toDelete,d];
                    end
                    notTreated(d) = 0;
                end
            end
        end
        notTreated(c) = 0;    
    end
end

report(toDelete) = [];

filteredReport = report;
