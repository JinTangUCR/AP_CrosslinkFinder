function [ms1,allSpectra,massList] = readMGF(fileName)

% first pass - to see how many MS2 spectrum points are there
fid = fopen(fileName,'rt');
ms2ionCounter = 0;
totalIons = 0;
readingIonList = 0;
lin = fgetl(fid);
while (lin~=-1)
    if (isempty(strfind(lin,'END IONS'))==0)
        readingIonList = 0;
        totalIons = totalIons + 1;
    end
    if (readingIonList)
        ms2ionCounter = ms2ionCounter + 1;
    else
        if (isempty(strfind(lin,'CHARGE'))==0) % the ions list begin (look into MGF file)
            readingIonList = 1;
        end
    end
    lin = fgetl(fid);
end
fclose(fid);
fprintf(1,'Total number of ions to read: %.0f\n',totalIons); % Purpose: to get the total number of ion(totalIons) and the total number of MS2 ions(ms2ionCounter)

fid = fopen(fileName,'rt');
allSpectra = zeros(ms2ionCounter,2);
massList = zeros(ms2ionCounter,5);
ms2Counter = 0; % Index the ion NO.
ms2ionCounter = 0; % return ms2ionCounter to zero
readingIonList = 0; % Index to start counting ms2
lin = fgetl(fid);
while (lin~=-1)
    if (isempty(strfind(lin,'END IONS'))==0)
        ms2Counter = ms2Counter + 1;
        if (mod(ms2Counter,1000) == 0)
            fprintf(1,'So far read %.0f ions\n',ms2Counter);
        end            
        ms1(ms2Counter).mz = mass;
        ms1(ms2Counter).ch = charge;
        ms1(ms2Counter).rt = rtTime;
        ms1(ms2Counter).scanN = scanNumber;
        if (ms2Counter==1)
            ms1(ms2Counter).startMS2ind = 1;
        else
            ms1(ms2Counter).startMS2ind = ms1(ms2Counter-1).endMS2ind + 1;
        end
        ms1(ms2Counter).endMS2ind = ms2ionCounter; % output the index for MS2 data, start and end
        ms1(ms2Counter).Ims2 = sum(allSpectra(ms1(ms2Counter).startMS2ind:ms1(ms2Counter).endMS2ind,2)) / 100; % Sum of their intensity
        ms1(ms2Counter).trueMass = ms1(ms2Counter).mz*ms1(ms2Counter).ch - 1.0072764*ms1(ms2Counter).ch;
        trueMassList = getTrueMasses(allSpectra(ms1(ms2Counter).startMS2ind:ms1(ms2Counter).endMS2ind,:));
        if (ms2Counter==1)
            ms1(ms2Counter).startTrueMassInd = 1;
            ms1(ms2Counter).endTrueMassInd = length(trueMassList(:,1));
        else
            ms1(ms2Counter).startTrueMassInd = ms1(ms2Counter-1).endTrueMassInd + 1;
            ms1(ms2Counter).endTrueMassInd = ms1(ms2Counter-1).endTrueMassInd + length(trueMassList(:,1));
        end
        massList(ms1(ms2Counter).startTrueMassInd:ms1(ms2Counter).endTrueMassInd,:) = trueMassList;
        ms1(ms2Counter).fit_type1 = [];
        ms1(ms2Counter).fit_type2 = [];
        ms1(ms2Counter).fit_type3 = [];
        readingIonList = 0;
    end
    if (readingIonList)
        ionData = str2num(lin);
        ms2ionCounter = ms2ionCounter + 1;
        allSpectra(ms2ionCounter,:) = ionData;
    else
        if (isempty(strfind(lin,'PEPMASS='))==0) %extract the mass from mgf file
            dotIdx1 = strfind(lin,'.');
            firstdot1 = dotIdx1(1);
            mass1 = str2num(lin(9:end));
            mass = mass1(1);
        end
        if (isempty(strfind(lin,'CHARGE'))==0)
            qualIdx2 = strfind(lin,'=');
            lastequal2 = qualIdx2(end);
            charge = str2num(lin(lastequal2+1));
            readingIonList = 1; % to start counting ms2 ions
        end
        if (isempty(strfind(lin,'RTINSECONDS='))==0)
            qualIdx3 = strfind(lin,'=');
            lastequal3 = qualIdx3(end);
            dotIdx2 =strfind(lin,'.');
            firstdot2 = dotIdx2(1);
            rtTime = str2num(lin((lastequal3+1):end));
        end
        if (isempty(strfind(lin,'scan='))==0)    
            qualIdx4 = strfind(lin,'=');
            lastequal4 = qualIdx4(end);
            scanNumber = str2num(lin((lastequal4+1):(end-1)));
        end
    end
    lin = fgetl(fid);
end
fclose(fid);
massList((ms1(ms2Counter).endTrueMassInd+1):end,:) = [];


