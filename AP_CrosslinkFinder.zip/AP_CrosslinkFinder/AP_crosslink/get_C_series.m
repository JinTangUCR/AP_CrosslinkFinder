function C_Series = get_C_series(dna)

C_Series = [];
for c=1:(length(dna)-1)
    C_Series = [C_Series , sum(dna(1:c))]; % all C ions
end