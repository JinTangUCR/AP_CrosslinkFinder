function AminusB_Series = get_AminusB_Series(dna,seq)
global adenine thymine cytosine guanine uracil
AminusB_Series = [];
for c=1:(length(dna))
    if seq(c)=='A'||seq(c)=='a'
    AminusB_Series = [AminusB_Series , (sum(dna(1:c))-adenine)]; % all a ions lost adenine
    end
    if seq(c)=='T'
        AminusB_Series = [AminusB_Series , (sum(dna(1:c))-thymine)]; % all a ions lost thymine
    end
    if seq(c)=='u'
        AminusB_Series = [AminusB_Series , (sum(dna(1:c))-uracil)]; % all a ions lost uracil
    end
    if seq(c)=='C'||seq(c)=='c'
        AminusB_Series = [AminusB_Series , (sum(dna(1:c))-cytosine)]; % all a ions lost cytosine
    end
    if seq(c)=='G'||seq(c)=='g'
        AminusB_Series = [AminusB_Series , (sum(dna(1:c))-guanine)]; % all a ions lost guanine
    end
end
% Also include the 3'-side lose of base group