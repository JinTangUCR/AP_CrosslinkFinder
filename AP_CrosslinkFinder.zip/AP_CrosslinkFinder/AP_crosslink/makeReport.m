pep2letter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ12345';

report = mergeIonReports(analysisFiles);

reportFile = fopen(reportFileName,'wt');

filteredReport = filterSiteRedundency(report);

% intensVec = zeros(length(filteredReport),1);
% for c=1:length(filteredReport)
%     intensVec(c) = filteredReport(c).intens;
% end
% [vals,inds] = sort(intensVec,'descend');
% inds = 1:length(intensVec);
inds = 1:length(filteredReport);
for c=1:length(filteredReport)
    theMasses = filteredReport(inds(c)).masses; %mass list in data
    [PScore,DScore,ppms,NinTop10] = scoreMS2externalXLStringent(theMasses, filteredReport(inds(c)).seqP , filteredReport(inds(c)).seqD , ...
                        filteredReport(inds(c)).linkP , filteredReport(inds(c)).linkD ,  0);
    if (PScore+DScore >= minBYnumToShow)
        fprintf(1,'********************************* %.0f *************************************************\n',c)
        fprintf(1,'%.0f  +%.0f  %.2f \n',filteredReport(inds(c)).intens,filteredReport(inds(c)).ch,filteredReport(inds(c)).relScore)
        fprintf(1,'%.0f-%.0f-%s-%.0f\n',filteredReport(inds(c)).ID_P,filteredReport(inds(c)).resP,filteredReport(inds(c)).seqP,filteredReport(inds(c)).linkP)
        fprintf(1,'%.0f-%.0f-%s-%.0f\n\n',filteredReport(inds(c)).ID_D,filteredReport(inds(c)).resD,filteredReport(inds(c)).seqD,filteredReport(inds(c)).linkD)
        [PScore,DScore,ppms,NinTop10] = scoreMS2externalXLStringent(theMasses, filteredReport(inds(c)).seqP , filteredReport(inds(c)).seqD , ...
            filteredReport(inds(c)).linkP , filteredReport(inds(c)).linkD , 1);
    end
    
    confStr = 'XXX';
    if ((PScore>3) & (DScore>3))
        confStr = '2'; % formerly 'high'
    elseif ((PScore>3) & (DScore>2))
        confStr = '1'; % formerly 'low'
    elseif ((PScore>2) & (DScore>3))
        confStr = '1'; % formerly 'low'
    else
        confStr = '0';
    end
    fprintf(reportFile,'%s %s %.0f %.0f %s %.2f %.0f %.0f +%.0f %.0f %s-%.0f %s-%.0f \n',... 
        pep2letter(filteredReport(inds(c)).ID_P), ...
        pep2letter(filteredReport(inds(c)).ID_D), ...
        processAbsPos(filteredReport(inds(c)).ID_P,filteredReport(inds(c)).resP+filteredReport(inds(c)).linkP-1), ...                    
        processAbsPos(filteredReport(inds(c)).ID_D,filteredReport(inds(c)).resD+filteredReport(inds(c)).linkD-1), ...
        confStr, ...
        (PScore+DScore)/(length(filteredReport(inds(c)).seqP)+length(filteredReport(inds(c)).seqD)),...
        NinTop10,...
        filteredReport(inds(c)).intens,...
        filteredReport(inds(c)).ch,...
        filteredReport(inds(c)).trueMass,...
        filteredReport(inds(c)).seqP,filteredReport(inds(c)).linkP,...
        filteredReport(inds(c)).seqD,filteredReport(inds(c)).linkD);
end
  

fclose(reportFile);
