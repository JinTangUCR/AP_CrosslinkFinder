% Reading the fasta sequences
global miscleave
fid = fopen(fastaFileName,'rt');
seqCounter = 0;
lin = fgetl(fid);
while (ischar(lin))
    if (lin(1)=='>')
        seqCounter = seqCounter + 1;
        seqs(seqCounter).description = lin;
        seqs(seqCounter).seq = [];
        if (seqCounter>1)
            fprintf('Read sequence %s \n%s\n',seqs(seqCounter-1).description,seqs(seqCounter-1).seq);
        end
    else
        seqs(seqCounter).seq = [seqs(seqCounter).seq , deblank(lin)];
    end
    lin = fgetl(fid);
end
fclose(fid);
fprintf('Read sequence %s \n%s\n',seqs(seqCounter).description,seqs(seqCounter).seq);

% Starting in-silico digestion
protein_digest = [];

for seqID = 1:length(seqs)
    seq = seqs(seqID).seq; % assign sequence to seq and perform the digestion one sequence by one sequence
    allInds = [0,strfind(seq,'K'),strfind(seq,'R')]; % all indexes idicating K and R
    noCut = [strfind(seq,'KP'),strfind(seq,'RP')]; % Remove the digestion at KP and RP
    for c=1:length(noCut)
        allInds(find(allInds==noCut(c))) = []; %remove the KP RP indexes in allInds
    end
    if (isempty(find(allInds==length(seq))))
        allInds=[allInds,length(seq)]; %include the protein c-term
    end
    cuts = sort(allInds,'ascend'); %sort the cut point in ascend

    for cutStartInd = 1:(length(cuts)-1) % index the cut number
        for cutEndInd = (cutStartInd+1):min(length(cuts),cutStartInd+miscleave+1)
            initialDigest = seq((cuts(cutStartInd)+1):cuts(cutEndInd));
            finalDigest = initialDigest;
            metInds = strfind(finalDigest,'M');
            if (~isempty(metInds))
                newDigest = finalDigest;
            else
                newDigest = [];
            end
            for C= 1:length(metInds)
                for B = 1:size(newDigest,1)
                    newDigest1 = newDigest(B,:);
                    newDigest1(metInds(C)) = 'O';
                    newDigest = [newDigest;newDigest1];
                end
            end
            if (~isempty(metInds))
               for B = 1:size(newDigest,1) % Remove the same sequence
                   for A = (B+1):size(newDigest,1) 
                       if newDigest(B,:) == newDigest(A,:)
                          newDigest(B,:) = [];
                       end
                   end
               end
               newDigest(1,:)=[]; % remove the first array which is the same as the 2nd array
            end
            finalDigest = strvcat(finalDigest,deblank(newDigest));
                
            % Putting an oxTrp
            wInds = strfind(initialDigest,'W');
            if (~isempty(wInds))
               newDigest = [];
               for A = 1:size(finalDigest,1)
                   for C=1:length(wInds)
                       newDigest1 = finalDigest(A,:);
                       newDigest1(wInds(C)) = 'J'; % W+4
                       newDigest = [newDigest;newDigest1]; %include the modified sequence
                   end
               end
               for A = 1:size(finalDigest,1)
                   for C=1:length(wInds)
                       newDigest1 = finalDigest(A,:);
                       newDigest1(wInds(C)) = 'U'; % W+16
                       newDigest = [newDigest;newDigest1]; %include the modified sequence
                   end
               end
               for A = 1:size(finalDigest,1)
                  for C=1:length(wInds)
                      newDigest1 = finalDigest(A,:);
                      newDigest1(wInds(C)) = 'Z'; % W+20
                      newDigest = [newDigest;newDigest1]; %include the modified sequence
                  end
               end
               for A = 1:size(finalDigest,1)
                   for C=1:length(wInds)
                      newDigest1 = finalDigest(A,:);
                      newDigest1(wInds(C)) = 'z'; % W+32
                      newDigest = [newDigest;newDigest1]; %include the modified sequence
                   end
               end
               finalDigest = strvcat(finalDigest, deblank(newDigest));
            else
               newDigest = [];
            end   
            for seqC = 1:size(finalDigest,1)
                if (length(deblank(finalDigest(seqC,:)))>=minPepLength)
                    addInd = length(protein_digest)+1;
                    protein_digest(addInd).seq = deblank(finalDigest(seqC,:));
                    protein_digest(addInd).startRes = cuts(cutStartInd)+1;
                    protein_digest(addInd).ID = seqID;
                end
            end
        end
    end
end

return


