function W_Series = get_W_series(dna)

global waterMass

W_Series = [];
for c=2:length(dna)
    W_Series = [W_Series , sum(dna(c:end))+waterMass];
end
